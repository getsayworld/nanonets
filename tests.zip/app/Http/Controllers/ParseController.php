<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ParseController extends Controller
{
    //

    public function PredictionforImageFile(Request $request)
    {

        $files = [];
        if ($request->hasFile("document")) {
            foreach ($request->file('document') as $key => $file) {
                if ($file->isValid()) {
                    $files["file"] = curl_file_create(
                        $file->getPathname(),
                        $file->getClientMimeType(),
                        $file->getClientOriginalName()
                    );;
                }
            }
        }
        // dd($files);
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://app.nanonets.com/api/v2/OCR/Model/cd2d42f1-307d-48f6-ad0b-d689bd0a3936/LabelFile/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $files,
            CURLOPT_HTTPHEADER => array(
                "Authorization: Basic ".base64_encode("52361f88-0189-11ef-8d7e-e65b8aca6ee3")
            ),
        ));

        $response = curl_exec($curl);

        if ($response === false) {
            $error = curl_error($curl);
            // Handle the error
            echo "$error";
        } else {
            // Check if the response is not empty
            if (!empty($response)) {
                // Response received, handle it
                echo "Response: $response";
            } else {
                // Empty response, handle it accordingly
                echo "Empty response received";
            }
        }

        curl_close($curl);
        // dd($response);
    }
}
