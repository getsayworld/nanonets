<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <form action="{{ url('upload') }}" method="post" id="form" enctype="multipart/form-data">
                        @csrf

                        <div class="form-group">
                          <label class="custom-file"  >
                              <input type="file" name="document" id="" placeholder="" class="custom-file-input" aria-describedby="fileHelpId">
                              <span class="custom-file-control">Upload Document</span>
                          </label>
                        </div>

                        <div class="form-group">

                            <button class="btn btn-primary"> Upload</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>
